﻿using System.Security.Cryptography.X509Certificates;
namespace ConsoleApp3
{

    public class Unit
    {
        public int Name { get { return Name; } }
        public int Hp { get { return Hp; } }
        public int Att { get { return Att; } }
    }

    internal class Program
    {


        static void Main(string[] args)
        {
           Console.Clear(); 
            int a =1;
            Console.WriteLine("이름 : asd");
            Console.WriteLine("체력 : 10");
            Console.WriteLine("공격력 : 3");
                
               Console.WriteLine("싸운다 ");
                Console.WriteLine("대기한다");
            ConsoleKeyInfo keyInfo = Console.ReadKey();
            while (a==1)
            {
                Console.WriteLine("공격");
                Console.WriteLine("대기");
                break;
            }

            switch(keyInfo.Key)
            {
                
            }
            Console.ReadLine();
           
                  
                
                
            }

        }
    }

